package com.example.courseworkitfu.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class FoodOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private LocalDateTime createdAt;
    private LocalDateTime deliveredAt;

    @ManyToOne
    private Client buyer;

    @ManyToOne
    private Driver deliveryPerson;

    @ManyToOne
    private Restaurant restaurant;

    @Enumerated(EnumType.STRING)
    private Cuisine cuisine;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    private double totalPrice;
    private double deliveryFee;
    private String paymentMethod;
    private int estimatedDeliveryMin;
    private String specialInstructions;

    @ManyToMany
    private List<Dish> items;
}