package com.example.courseworkitfu.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

public class Review extends Message{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String text;
    private int rating;
    private String title;
    private LocalDateTime reviewDate;
    private Restaurant reviewedRestaurant;
    private Driver reviewedDriver;
}
