package com.example.courseworkitfu.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@Entity
public class Dish {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int calories;

    private String category;

    private String description;

    private String imageUrl;

    private boolean isAvailable;

    private int preparationTimeMin;

    private float price;

    private String title;

    private float weight;

    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;
}